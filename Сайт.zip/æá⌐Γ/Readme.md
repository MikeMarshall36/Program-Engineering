# Сайт
<h3>Здесь находится вся информация про сайт проекта</h3>
<ul>
  <li>Сам код и исходники</li>
  <li>Сценарии тестирования (https://docs.google.com/spreadsheets/d/1ja60dlrtqHvjhVgbV8YHFkrm4EMiUkrWd3IsZ0gxH-k/edit#gid=0)</li>
  <li>Тесты</li>
</ul>
